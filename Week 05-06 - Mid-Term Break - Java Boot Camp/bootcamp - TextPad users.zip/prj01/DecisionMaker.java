//package com.bootcamp.prj01;

/**
 *
 * @author sanatif
 * A class to demonstrate Decision making code structure
 */
public class DecisionMaker {



     // ***   Exercise 01  ***
     //   Time to complete: 5 minutes

    // Declare a private static method called displayOdds that returns nothing and has one Parameter of type int called 'limit'

    // inside displayOdds method create a 'for' loop to iterate from 0 to the 'limit'

    // inside the 'for' loop create a condition to print the numbers only if they are odd




     // ***   Exercise 02  ***
     //   Time to complete: 3 minutes

    // write a 'main' method for this class and call the displayOdds
    // run the program and observe the output




     // ***   Exercise 03  ***
     //   Time to complete: 2 minutes

    // declare and populate a static array of names




     // ***   Exercise 04  ***
     //   Time to complete: 8 minutes

    // declare and implement a method called FindAPerson
    // that takes a string as argument called 'personeToFind' and
    // looks through and array of 'names' in Exercise 03
    // looking for a name that matches the 'personeToFind'
    // it returns the index of the name in the array if found
    // and return -1 if not found

}
