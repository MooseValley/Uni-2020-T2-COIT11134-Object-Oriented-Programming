/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package com.bootcamp.prj03;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author sanatif
 */
public class MyDatePicker extends JFrame implements ActionListener{

    JLabel dateDisplay = new JLabel(" -- / -- / -- ", JLabel.CENTER);

    JButton button = new JButton("ShowDate");

    private JLabel lblDay=new JLabel("Day");
    private JComboBox  dayChoice = new JComboBox (); // Drop down combo box

    private JLabel lblMonth=new JLabel("Month");
    private JComboBox  monthChoice = new JComboBox (); // Drop down combo box

    private Label lblYear=new Label("Year");
    private JComboBox  yearChoice = new JComboBox (); // Drop down combo box


    JPanel datePickerPanel = new JPanel();


    public MyDatePicker() {
        super("My date Picker Frame");
        setLayout(new BorderLayout());
        datePickerPanel.setLayout(new FlowLayout());


        datePickerPanel.add(lblDay);
        datePickerPanel.add(dayChoice);
        // @TODO  write a for loop to add numbers from 1-31 to the 'dayChoice'


        datePickerPanel.add(lblMonth);
        datePickerPanel.add(monthChoice);
        // @TODO  write a for loop to add numbers from 1-12 to the 'monthChoice'


        datePickerPanel.add(lblYear);
        datePickerPanel.add(yearChoice);
        // @TODO  @TODO  write a for loop to add numbers from 2000-2020 to the 'yearChoice'


        // @TODO  add the 'button' to the 'datePickerPanel'

        // @TODO  add Action Listener to the 'button'
        button.addActionListener(this);

        datePickerPanel.add(dateDisplay);

        // @TODO  add 'datePickerPanel' to the frame

        setBounds(200, 100, 300, 200);
    }


        //process button event
        public void actionPerformed(ActionEvent e)
   {

            // the next three lines are getting the data from combo boxes and store them in variables
            int day = dayChoice.getSelectedIndex()+1;
            int month = monthChoice.getSelectedIndex()+1;
            int year =  yearChoice.getSelectedIndex()+2010;

            // get the source of the event from the even object
            Object source = e.getSource();

            // @TODO  check if the source of the event == to object 'button'
            // @TODO  if true call the 'setPickedDate' method


        }//end of method

        // what this method does?
     private void setPickedDate(int day, int month , int year) {
        String strDate = day+" / "+month+ " / "+year;
        dateDisplay.setText(strDate);
    }



    public static void main(String[] args) {

       // @TODO  instantiate an object of this fram and set it ot visable

    }

}
