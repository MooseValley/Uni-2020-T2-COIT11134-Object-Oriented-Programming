/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package com.bootcamp.prj05;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author sanatif
 */
public class ViewBookPanel extends JPanel  {

        JPanel panelBookInput = new JPanel();

        JLabel lblAuthor = new JLabel("Author: ");
        JLabel lblTitle = new JLabel("Title ");

        JTextField txtAuthor = new JTextField(40);
        JTextField txtTitle = new JTextField(40);

        JTextArea taBookView = new JTextArea();

        JLabel lblStatus = new JLabel ("Status");

        JPanel panelStatus = new JPanel();

        JButton btnSearchByAuthor = new JButton("Search by Author");
        JButton btnSearchByTitle = new JButton("Search by Title");
        JButton btnViewAll = new JButton("View All");


    public ViewBookPanel( ) {
        this.setLayout(new BorderLayout());

        panelBookInput.setLayout(new GridLayout(3,4));

        panelBookInput.add(lblAuthor);
        panelBookInput.add(txtAuthor);
        panelBookInput.add(new JLabel ("        "));
        panelBookInput.add(btnSearchByAuthor);

        panelBookInput.add(lblTitle);
        panelBookInput.add(txtTitle);
        panelBookInput.add(new JLabel ("        "));
        panelBookInput.add(btnSearchByTitle);

        panelBookInput.add(new JLabel ("        "));
        panelBookInput.add(new JLabel ("        "));
        panelBookInput.add(new JLabel ("        "));
        panelBookInput.add(btnViewAll);


        taBookView.setText("Book Information");

        panelStatus.setLayout(new GridLayout(1,1));
        panelStatus.add(lblStatus);

        this.add(panelBookInput,BorderLayout.NORTH);
        this.add(taBookView,BorderLayout.CENTER);//?
        this.add(panelStatus,BorderLayout.SOUTH);
    }



}
