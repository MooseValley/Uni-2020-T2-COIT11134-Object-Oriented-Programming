/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bootcamp.prj05;

import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author sanatif
 * class to create and display all GUI components 
 */
public class BookStoreFrame extends JFrame {

    
    public static ArrayList bookArray;

    public BookStoreFrame()
    {
        super("Book Store Application");
        
        bookArray = new ArrayList();
        
        JPanel mainPanel=new JPanel();
         mainPanel.setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Add Published Book", new PrintedBookPanel());
        tabbedPane.addTab("Add Electronic Book", new EBookPanel());
        tabbedPane.addTab("Vew Books",  new ViewBookPanel());


        JLabel titleLabel=new JLabel(" My Library");
        titleLabel.setFont(new java.awt.Font("Trebuchet MS",0,24));

        //add(titleLabel);
        mainPanel.add(titleLabel,BorderLayout.NORTH);
        //add(tabbedPane);
        mainPanel.add(tabbedPane,BorderLayout.CENTER);

        add(mainPanel);

    }

}
