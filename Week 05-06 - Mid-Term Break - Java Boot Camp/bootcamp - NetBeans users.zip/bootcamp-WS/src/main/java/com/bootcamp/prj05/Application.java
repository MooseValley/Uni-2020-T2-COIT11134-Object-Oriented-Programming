/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bootcamp.prj05;

/**
 *
 * @author sanatif
 */
public class Application {
   
    public static void main(String[] args) {

        BookStoreFrame myApp=new BookStoreFrame();
        myApp.setVisible(true);
        myApp.setSize(650, 450);
        myApp.setDefaultCloseOperation(BookStoreFrame.EXIT_ON_CLOSE);

    }
    
    
}
