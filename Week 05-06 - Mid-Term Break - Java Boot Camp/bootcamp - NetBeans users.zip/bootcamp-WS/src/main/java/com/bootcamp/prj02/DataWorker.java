package com.bootcamp.prj02;

import java.util.Scanner;

/**
 *
 * @author sanatif
 */

public class DataWorker {
    
    private static String[] names;

    public static int getUserInput(){
        
        int count;
        // @TODO declare and instantiate an object of type Scanner
        
        System.out.print("Enter number of elements you want in the array: ");

        // @TODO use the scanner object to get the user input and store it in varaible 'count'

        // @TODO What this line of code dose?
        names = new String[count];
        
        System.out.println("Enter array elements:");

        // declare a for loop that iterates from 0 to 'count'
        {
            // inside the loop get the user input strings and 
            // assign them to locations in the array 'names'
        }
        
        return count;
    }

    public static void main(String[] args) {

        int counter ;
        
        // call the getUserInput and store its returned value in 'counter'
        
        System.out.println("========= You entered these names ===========");
        for (int k = 0; k < counter; k++) {
            System.out.println(names[k]);
        }
    }
    
    
}
