/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package com.bootcamp.prj05;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author sanatif
 */
public class PrintedBookPanel extends JPanel {

        JPanel panelBookInput = new JPanel();

        JLabel lblAuthor = new JLabel("Author: ");
        JLabel lblTitle = new JLabel("Title ");
        JLabel lblISBN = new JLabel("ISBN ");

        JTextField txtAuthor = new JTextField(40);
        JTextField txtTitle = new JTextField(40);
        JTextField txtISBN = new JTextField(40);

        JTextArea taBookView = new JTextArea();

        JLabel lblStatus = new JLabel ("Status");

        JPanel panelStatus = new JPanel();

        JButton btnSave = new JButton("Save");
        JButton btnClear = new JButton("Clear");


    public PrintedBookPanel( ) {
        this.setLayout(new BorderLayout());

        panelBookInput.setLayout(new GridLayout(4,4));

        panelBookInput.add(lblAuthor);
        panelBookInput.add(lblTitle);
        panelBookInput.add(lblISBN);

        panelBookInput.add(txtAuthor);
        panelBookInput.add(txtTitle);
        panelBookInput.add(txtISBN);

        panelBookInput.add(btnClear);
        panelBookInput.add(btnSave);
        panelBookInput.add(new JLabel ("        "));

        panelBookInput.add(new JLabel ("        "));
        panelBookInput.add(new JLabel ("        "));
        panelBookInput.add(new JLabel ("        "));

        taBookView.setText("Book Information");

        panelStatus.setLayout(new GridLayout(1,1));
        panelStatus.add(lblStatus);

        this.add(panelBookInput,BorderLayout.NORTH);
        this.add(taBookView,BorderLayout.CENTER);//?
        this.add(panelStatus,BorderLayout.SOUTH);



    }


}
